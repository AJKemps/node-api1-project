// import express from "express"; // ES2015 modules
const express = require("express"); // CommonJs modules
const shortid = require("shortid");

const server = express();

server.use(express.json()); // <-- teaches express how to read JSON from body

let users = [{ name: "Maryam" }, { name: "Charlie" }, { name: "Jonathan" }];
let accounts = [
    { id: shortid.generate(), name: "Maryam" },
    { id: shortid.generate(), name: "Charlie" },
    { id: shortid.generate(), name: "Jonathan" },
];

// show a list of users
server.get("/users", (req, res) => {
    res.status(200).json(users);
});

// add a user
server.post("/users", (req, res) => {
    const user = req.body; //< -- needs express.json() middleware

    users.push(user);

    res.status(201).json(users);
});

// remove a user
server.delete("/users/:name", (req, res) => {
    const name = req.params.name.toLocaleLowerCase();

    users = users.filter(u => u.name.toLocaleLowerCase() !== name);

    res.status(204).end();
});

// update a user
server.put("/users/:name", (req, res) => {
    // write this one!
});

// add a account
server.post("/accounts", (req, res) => {
    const account = req.body; //< -- needs express.json() middleware

    account.id = shortid.generate();

    accounts.push(account);

    res.status(201).json(accounts);
});

// update an account
server.put("/accounts/:id", (req, res) => {
    const id = req.params.id;
    const changes = req.body;

    let found = accounts.find(a => a.id === id);

    if (found) {
        Object.assign(found, changes);

        res.status(200).json(accounts);
    } else {
        res.status(404).json({ message: `There is no account with id ${id}` });
    }
});

server.get("/hello", (req, res) => {
    res.send("hello Web 32");
});

server.get("/accounts", (req, res) => {
    res.status(200).json(accounts);
});

const port = 8000;
server.listen(port, () => console.log("server running..."));
