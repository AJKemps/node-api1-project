# Notes

## keep a list of dependencies

-   generate a package.json file: `npm init -y`

## ignore node_modules folder content

-   we don't want to push it up to GitHub
-   make a `.gitignore`: `npx gitignore node`

## first server

-   create an `index.js` file at the project's root.
-   install express: `npm i express`.
-   use `require()` instead of `import`.
-   run the server with `node index.js`.
-   make a GET request to `localhost:8000/hello` to test it.
-   install nodemon as a dev dependency: `npm i -D nodemon`.
-   add the server script: `"server": "nodemon index.js"` inside package.json.
-   to run the server use: `npm run server`.

## Practice

-   make and endpoint `/accounts` that sends an array with 3 accounts, each account should have a unique `id` and a `name` property.
    -   bonus points if you use `shortid` for the unique ids.

## making a POST with Postman

-   select POST from the menu left of URL input.
-   go to `body` tab under URL input.
-   pick `raw`.
-   select `JSON` from the right most drop down (has `text` by default).
-   feel in the data.
